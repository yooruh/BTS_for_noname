// 阿哈（原创角色，非太阳神移植——源 animal.lua 无阿哈）—— 愿力、愉使与欢愉万相。
// 技能：阿哈！（必杀技·弃8愿力连发【欢愉万相】）、愉使（弃杀钦定唯一欢愉令使，不限次；被指定者可用1张
// 虚拟【杀】）、公演（使用/弃置【杀】或执行欢愉行动攒愿力）。规则：①【无中生有】在阿哈手上变为【欢愉万相】；②阿哈时刻——欢愉时刻
// （源 FunnyTime）除洗牌触发（rules/globalrules.js bts_gamerule_funny）外，由【阿哈！】技能持有者的准备阶段
// 额外降临（技能跟随：持有者不限定为阿哈本人）；③欢愉角色的伤害取消由共享技能【欢愉约束】
// bts_sk_funny_lock 承载（阿哈本人也持带；「欢愉升格」豁免）。
import { lib, game, ui, get, ai, _status, styleText, X, Y, Z, B, O } from '../../shared.js';
export const sort = 'erxiangleyuan';
export const title = '虚数·欢愉·欢愉星神'; // 称号
export const intro =
    `${B('阿哈')}是欢愉本身：以${get.poptip('bts_glossary_yuanli_faq')}驱动${B(get.poptip('bts_sk_aha'))}让【${get.poptip('bts_glossary_huanju_wanxiang_faq')}】在出牌阶段接连上演，${B(get.poptip('bts_sk_yushi'))}钦定${get.poptip('bts_glossary_huanju_lingshi_faq')}代收信仰，${B(get.poptip('bts_sk_gongyan'))}为每一次谢幕累积愿力；当阿哈登台，${get.poptip('bts_glossary_aha_moment_faq')}降临——欢愉角色得以${get.poptip('bts_glossary_huanju_shengge_faq')}，暂获伤人的自由。` +
    `<li>${B(get.poptip('bts_sk_gongyan'))}用【杀】与欢愉行动攒愿力至8枚即可发动${B(get.poptip('bts_sk_aha'))}；欢愉角色造成的伤害原会被欢愉规则取消（源版约束），唯${get.poptip('bts_glossary_huanju_shengge_faq')}者例外`;

export const character = {
    bts_ch_aha: {
        sex: 'female',
        group: 'erxiangleyuan',
        hp: 4,
        skills: ['bts_sk_aha', 'bts_sk_yushi', 'bts_sk_gongyan', 'bts_sk_funny_lock'],
    },
};

export const skill = {
    // ── 必杀技·阿哈！（源 max_aha；本移植为原创实现，V2.5 跟进「星启首次只花4枚」）──
    // 出牌阶段，弃8枚愿力（若你为星启则首次只花4枚）：此刻立即视为使用【欢愉万相】，并在接下来的两个出牌阶段开始时各再使用一次。
    bts_sk_aha: {
        // 终结技（原创必杀，描述以「必杀技」开头；bts_bisha 标签供技能按 id 识别终结技）
        bts_bisha: true,
        bts_funny_skill: true, // 欢愉技标签：funnyPlayer 按此判定（含【阿哈！】持有者）
        bts_bisha_angry: false, // 资源型必杀（愿力发动、不消耗怒气）→ 拥有者不获得怒气（utils.hasAngryBisha 门控）
        enable: 'phaseUse',
        filter(event, player) {
            // 源 max_ahaVS（V2.5 L12360）：n = 4（星启首发优惠）或 8。
            // 「首发」= 本局尚未发动过；以 storage 布尔记录（不占标记图位）。
            return player.countMark('bts_mk_yuanli') >= lib.bts.api.ahaCost(player);
        },
        async content(event, trigger, player) {
            lib.bts.aiGuard.record(player, 'bts_sk_aha');
            const cost = lib.bts.api.ahaCost(player);
            if (lib.bts.api.god(player) && !player.storage.bts_aha_discount_used)
                player.storage.bts_aha_discount_used = true; // 星启首发优惠已用
            player.removeMark('bts_mk_yuanli', cost);
            // 此刻：立即视为使用【欢愉万相】
            await lib.bts.api.useHuanjuWanxiang(player);
            // 之后的两个出牌阶段开始时各再放一次（计数待发；重复发动叠加——用户定夺）
            player.addMark('bts_mk_aha_pending', 2);
        },
        group: ['bts_sk_aha_after', 'bts_sk_aha_rule'],
        subSkill: {
            // 待放结算：出牌阶段开始时消耗1枚计数并视为使用【欢愉万相】（银狼999·无启 pending 标记范式）
            after: {
                trigger: { player: 'phaseUseBegin' },
                forced: true,
                filter(event, player) {
                    return player.countMark('bts_mk_aha_pending') > 0;
                },
                async content(event, trigger, player) {
                    player.removeMark('bts_mk_aha_pending', 1);
                    await lib.bts.api.useHuanjuWanxiang(player);
                },
            },
            // 规则技（非显示）：①【无中生有】在阿哈手上变为【欢愉万相】；②阿哈时刻（欢愉时刻改由阿哈准备阶段触发）
            rule: {
                name: '欢愉规则',
                trigger: { player: 'phaseZhunbeiBegin' },
                forced: true,
                popup: false,
                async content(event, trigger, player) {
                    // 阿哈时刻：欢愉时刻（源 FunnyTime）——洗牌触发已由规则层 bts_gamerule_funny
                    // 承担；本子技跟随【阿哈！】技能持有者（非绑定角色），在持有者的准备阶段
                    // 开始时额外降临一次 → 全场各执行一次欢愉行动（funnyAct 按各技能的 bts_funny
                    // 注册表泛化派发，含阿哈自己的「视为使用【欢愉万相】」行动）。
                    // initiator=event.name（本规则子技无自动日志）→ 行动执行时由 funnyAct 补记各技能日志。
                    await lib.bts.api.funnyTime(null, null, null, event.name);
                },
                mod: {
                    cardname(card, player, name) {
                        // 规则①：本次使用中，阿哈手上的【无中生有】按【欢愉万相】结算
                        //（useCard 创建时经 VCard→get.name(card, owner) 走本 mod 链改名）
                        if (name === 'wuzhong') return 'bts_cd_huanju_wanxiang';
                    },
                },
            },
        },
        // 欢愉行动注册（自注册重构）：funnyAct 泛化派发时执行——视为使用【欢愉万相】
        //（阿哈（原创）：其【无中生有】已按规则变为万相；体系统一入口 utils.useHuanjuWanxiang）。
        bts_funny: {
            order: 10,
            async act(ctx) {
                await lib.bts.api.useHuanjuWanxiang(ctx.player);
                ctx.done = true;
            },
        },
        ai: {
            // AI 口径：愿力≥8（filter 门控）即发动——收益=3 次万相（自己+令使+全场各摸1、欢愉升格）；
            // 令使在场时万相额外给其摸1，评分略高（原创设计）
            order(item, player) {
                if (lib.bts.aiGuard.blocked(player, 'bts_sk_aha')) return -1;
                return game.hasPlayer(
                    (p) => p.isAlive() && p.countMark('bts_mk_huanju_lingshi') > 0,
                )
                    ? 9
                    : 8;
            },
            // 自己摸 1~2 张 + 欢愉升格；万相结算详见 card/bts_cd
            result: { player: 2 },
        },
    },

    // ── 主动技·愉使（V2.5 跟进源 st_yushi 重做：令使唯一 + 令使视为对你所选目标用【杀】）──
    // 出牌阶段（不限次），弃置一张【杀】并选择一名其他角色（不可选自己）：其成为唯一的「欢愉令使」。
    // 键名 bts_sk_yushi 与源 V2.5 一致（源把风堇·愈世 改名为 st_yuchen 后腾出该名）。
    bts_sk_yushi: {
        enable: 'phaseUse',
        usable: Infinity, // 「每回合无限制」（显式声明；不写 usable 时本就不限次）
        filter(event, player) {
            // 须有【杀】可弃，且存在其他存活角色（filterTarget 要求 t!==p），否则无目标可选
            return (
                player.countCards('he', (card) => get.name(card) === 'sha') > 0 &&
                game.hasPlayer((target) => target !== player && target.isAlive())
            );
        },
        filterCard(card, player) {
            return (
                get.name(card) === 'sha' &&
                lib.filter.cardDiscardable(card, player)
            );
        },
        selectCard: 1,
        position: 'he',
        filterTarget(card, player, target) {
            return target !== player; // 其他角色（不可选自己）
        },
        selectTarget: 1,
        async content(event, trigger, player) {
            lib.bts.aiGuard.record(player, 'bts_sk_yushi');
            await player.discard(event.cards);
            // 欢愉令使唯一：先撤全场旧令使，再授予新令使（换人即转移）
            // 含死者（源 getAllPlayers 清标记，V2.5 §四-C）：第三参 true = includeOut，
            // 避免阵亡者的残留令使标记挡住后续授予。
            for (const p of game.filterPlayer(
                (p) => p.countMark('bts_mk_huanju_lingshi') > 0,
                [],
                true,
            )) {
                p.removeMark(
                    'bts_mk_huanju_lingshi',
                    p.countMark('bts_mk_huanju_lingshi'),
                );
            }
            const target = event.targets[0];
            target.addMark('bts_mk_huanju_lingshi', 1);
            // 源 st_yushiCard.on_use 尾段（V2.5 L12417-12424）：令使视为对你选中的另一名其他角色使用【杀】。
            // 候选＝其他角色中排除令使者，且以令使视角合法可用（含距离/禁手）——源只判 isProhibited，
            // 无名杀把「视为使用」的合法性统一按 canUse 处理（更严格，避免出现非法【杀】）。
            if (!target.isAlive()) return;
            const vsha = { name: 'sha', isCard: true };
            const candidates = game.filterPlayer(
                (p) =>
                    p.isAlive() &&
                    p !== player &&
                    p !== target &&
                    target.canUse(vsha, p, true),
            );
            if (!candidates.length) return; // 源 others:isEmpty() → 不使用
            // 候选唯一（如残局只剩三人）时直接指定，不再弹一次「选谁挨这一刀」的窗口。
            let to = candidates[0];
            if (candidates.length > 1) {
                const chosen = await player
                    .chooseTarget(
                        `愉使：选择令使${get.translation(target)}视为对其使用【杀】的角色`,
                        [1, 1],
                        (card, p, t) =>
                            t !== p &&
                            t !== target &&
                            target.canUse(vsha, t, true),
                    )
                    // AI 口径：由阿哈选目标，取「对阿哈的收益」= get.effect(目标, 杀, 令使, 阿哈)（对敌为正）
                    .set('ai', (t) => get.effect(t, vsha, target, player))
                    .forResult();
                to = chosen.targets?.[0];
                if (!to) return;
            }
            await target.useCard(vsha, to, 'bts_sk_yushi');
        },
        group: ['bts_sk_yushi_lingshi'],
        subSkill: {
            // 欢愉令使的回合开始时，阿哈获得1枚愿力
            lingshi: {
                trigger: { global: 'phaseZhunbeiBegin' },
                forced: true,
                popup: false,
                filter(event, player) {
                    return event.player.countMark('bts_mk_huanju_lingshi') > 0;
                },
                async content(event, trigger, player) {
                    player.addMark('bts_mk_yuanli', 1);
                },
            },
        },
        ai: {
            // AI 口径：弃1【杀】换唯一令使（其回合开始+1愿力）；已有友方令使不再换人（白耗杀）；
            // 距8愿力临门（≥6）时借令使管道加速（原创设计）
            order(item, player) {
                if (lib.bts.aiGuard.blocked(player, 'bts_sk_yushi')) return -1;
                const lingshi = game.filterPlayer(
                    (p) => p.isAlive() && p.countMark('bts_mk_huanju_lingshi') > 0,
                );
                if (lingshi.length && lingshi.every((p) => get.attitude(player, p) >= 0))
                    return -1;
                const sha = player.countCards('he', (c) => get.name(c) === 'sha');
                if (!sha) return -1; // filter 兜底（防按钮评估期误评）
                if (player.countMark('bts_mk_yuanli') >= 6) return 6;
                return sha >= 2 ? 4 : 2;
            },
            result: {
                // 令使管道每回合+1愿力（持续收益）；目标获1张虚拟【杀】机会=目标获益（态度加权排除敌方）
                player: (player) => (player.countMark('bts_mk_yuanli') >= 6 ? 2 : 1.5),
                target: 1,
            },
        },
    },

    // ── 锁定技·公演（原创设计）──
    // 当你使用或弃置【杀】，或执行欢愉行动（使用/视为使用【无中生有】或【欢愉万相】）后，获得1枚愿力。
    bts_sk_gongyan: {
        trigger: { player: ['useCard', 'loseAfter'] },
        forced: true,
        filter(event, player, triggername) {
            if (triggername === 'loseAfter') {
                // 弃置【杀】（照银狼999·狼尊的 discard 判据：含各途径弃置；不含“使用”进处理区）
                return (
                    event.type === 'discard' &&
                    (event.cards || []).some(
                        (card) => get.name(card) === 'sha',
                    )
                );
            }
            // 使用【杀】；【无中生有】在阿哈手上已变为【欢愉万相】，故直接判万相（含各种“视为使用”）
            return ['sha', 'bts_cd_huanju_wanxiang'].includes(event.card?.name);
        },
        async content(event, trigger, player) {
            player.addMark('bts_mk_yuanli', 1);
        },
        ai: {
            // AI 口径：使用【杀】/【欢愉万相】+1 愿力（与本技能 filter 的 useCard 判据同源）——计入
            // 施动侧约半枚牌值（[1,0.5]：result1 不动、temp01+0.5；仅作「对敌可选用」的激励，不改变
            // 出牌排序）；目标偏好：仅对敌（attitude<0）计入——防 AI 对友方/中立白甩【杀】。与
            // 【欢愉约束】叠用后：无升格对敌=0.5（可选用）、有升格=伤害收益+0.5（更优）。
            effect: {
                player(card, player, target, current) {
                    if (!card) return;
                    if (card.name !== 'sha' && card.name !== 'bts_cd_huanju_wanxiang') return;
                    if (target && get.attitude(player, target) >= 0) return; // 对友/中立：不计
                    return [1, 0.5];
                },
            },
        },
    },
};

export const marks = {
    // 愿力（阿哈资源标记；原创）
    bts_mk_yuanli: {
        markKind: 'mark',
        markType: 'text',
        glossaryId: 'bts_glossary_yuanli_faq',
    },
    // 欢愉令使（唯一身份标记；换人即转移）
    bts_mk_huanju_lingshi: {
        markKind: 'mark',
        markType: 'text',
        glossaryId: 'bts_glossary_huanju_lingshi_faq',
    },
    // 欢愉升格（持续至该角色回合结束；'-clear' 后缀由 bts_gamerule_phase 于其回合结束时统一清理）
    'bts_mk_huanju_shengge-clear': {
        markKind: 'mark',
        markType: 'text',
        glossaryId: 'bts_glossary_huanju_shengge_faq',
    },
    // 阿哈·万相待放次数（出牌阶段开始时消耗；intro 文案见 translate _info）
    bts_mk_aha_pending: {
        markKind: 'mark',
        markType: 'text',
    },
};

export const glossary = [
    {
        id: 'bts_glossary_yuanli_faq',
        name: '愿力',
        info: `阿哈的资源标记：${get.poptip('bts_sk_gongyan')}与其欢愉令使的回合开始时赋予；「${get.poptip('bts_sk_aha')}」消耗8枚发动。`,
    },
    {
        id: 'bts_glossary_huanju_lingshi_faq',
        name: '欢愉令使',
        info: `由「${get.poptip('bts_sk_yushi')}」授予的唯一身份（再次授予则转移）：其回合开始时，阿哈获得1枚愿力。`,
    },
    {
        id: 'bts_glossary_huanju_shengge_faq',
        name: '欢愉升格',
        info: '由【欢愉万相】赋予：持续至该角色的回合结束。期间该角色造成的伤害不再被欢愉行动约束——欢愉角色造成的伤害原本会被欢愉规则取消。',
    },
    {
        id: 'bts_glossary_aha_moment_faq',
        name: '阿哈时刻',
        info: `【阿哈！】技能持有者的准备阶段开始时额外降临的${get.poptip('bts_glossary_funny_time_faq')}：全场角色各执行一次${get.poptip('bts_glossary_funny_act_faq')}。`,
    },
    {
        id: 'bts_glossary_huanju_wanxiang_faq',
        name: '欢愉万相',
        info: `阿哈与其欢愉令使各摸一张牌，目标摸一张牌，所有角色各摸一张牌；拥有欢愉行动的角色进入${get.poptip('bts_glossary_huanju_shengge_faq')}状态。`,
    },
];

export const translate = {
    bts_ch_aha: '阿哈',
    bts_sk_aha: '阿哈！',
    bts_sk_aha_info: `${get.poptip('bts_glossary_bisha_faq')}，${get.poptip('bts_glossary_funny_skill_faq')}，出牌阶段，你可以弃8枚${get.poptip('bts_glossary_yuanli_faq')}（若你为${get.poptip('bts_glossary_xingqi_faq')}则首次只需4枚），`
        + `此刻以及之后的两个出牌阶段开始时，你视为使用【${get.poptip('bts_glossary_huanju_wanxiang_faq')}】。`,
    bts_sk_yushi: '愉使',
    bts_sk_yushi_info: `出牌阶段（不限次），你可以弃置一张【杀】并选择一名其他角色，其于你下次发动此技能前视为${get.poptip('bts_glossary_huanju_lingshi_faq')}：其回合开始时，你获得1枚${get.poptip('bts_glossary_yuanli_faq')}。然后其视为对你选择的另一名其他角色使用【杀】。`,
    bts_sk_gongyan: '公演',
    bts_sk_gongyan_info: `锁定技，当你使用或弃置【杀】，或执行${get.poptip('bts_glossary_funny_act_faq')}后，你获得1枚${get.poptip('bts_glossary_yuanli_faq')}。`
        + `欢愉行动：使用或视为使用【无中生有】或【${get.poptip('bts_glossary_huanju_wanxiang_faq')}】。`,
    bts_mk_yuanli: '愿力',
    bts_mk_huanju_lingshi: '欢愉令使',
    'bts_mk_huanju_shengge-clear': '欢愉升格',
    bts_mk_aha_pending: '万相待放',
    bts_mk_aha_pending_info: '阿哈还能在之后的出牌阶段开始时视为使用【欢愉万相】（数字为剩余次数）。',
};

export const simpleTranslate = {
    bts_sk_aha_info: `${get.poptip('bts_glossary_bisha_faq')}；${get.poptip('bts_glossary_funny_skill_faq')}；-8${get.poptip('bts_glossary_yuanli_faq')}（${get.poptip('bts_glossary_xingqi_faq')}首发4），`
        + `此刻与之后2个出牌阶段开始时视为用欢愉万相`,
    bts_sk_yushi_info: `不限次；-1杀选一名其他角色为${get.poptip('bts_glossary_huanju_lingshi_faq')}（唯一）；其回合开始时你+1愿力；然后其视为对你选的另一名其他角色用杀`,
    bts_sk_gongyan_info: `锁；使用/弃置杀或执行${get.poptip('bts_glossary_funny_act_faq')}后+1${get.poptip('bts_glossary_yuanli_faq')}`,
};

export const pinyins = {}; // 如果默认的拼音正确，不需要再使用字符串数组定义拼音
