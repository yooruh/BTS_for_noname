// 三月七（源 animal.lua L1960-2028）—— 冰箭必杀技冻结群控、可爱给盾、特权（护盾抵扣后视为用杀，规则层）。
import { lib, game, ui, get, ai, _status, styleText, X, Y, Z, B, O } from '../../shared.js';export const sort = 'xingqionglieche';
export const title = '冰·存护·超超超超厉害的本姑娘☆'; // 属性·命途
export const intro =
    `${B('三月七')}是控场辅助：${get.poptip('bts_glossary_bisha_faq')}${B(get.poptip('bts_sk_bingjian'))}用${get.poptip('bts_glossary_nuqi_faq')}令多名角色${B(get.poptip('bts_glossary_abnormal_freeze_faq'))}，${B(get.poptip('bts_sk_keai'))}弃【杀】给盾，${get.poptip('bts_glossary_xingqi_faq')}时${get.poptip('bts_sk_bingjian')}还能回复${get.poptip('bts_glossary_nuqi_faq')}。` +
    `<li>${get.poptip('bts_glossary_abnormal_freeze_faq')}令目标禁装备牌且伤害基数-1，注意目标选择`;

export const character = {
    bts_ch_sanyueqi: {
        sex: 'female',
        group: 'xingqionglieche',
        hp: 3,
        skills: ['bts_sk_bingjian', 'bts_sk_tequan', 'bts_sk_keai'],
    },
};

export const skill = {
    // ── 必杀技·冰箭（源 st_bingjian = ZeroCardViewAsSkill，L1961-1978）──
    bts_sk_bingjian: {
        // 终结技（源必杀技 max_*，描述以「必杀技」开头；bts_bisha 标签供技能按 id 识别终结技）
        bts_bisha: true,
        enable: 'phaseUse',
        filter(event, player) {
            // enabled_at_play：怒气≥3
            return lib.bts.api.getAngry(player, 3);
        },
        filterTarget(event, player, target) {
            return target !== player;
        },
        selectTarget: [1, Infinity],
        multitarget: true, // 一次性结算；非 multitarget 会按目标重跑 content（《技能开发规范》B14）
        async content(event, trigger, player) {
            lib.bts.aiGuard.record(player, 'bts_sk_bingjian');
            lib.bts.api.loseAngry(player, 3); // 源 L1971
            for (const t of event.targets || []) {
                lib.bts.api.addAbnormal(t, 'freeze', 1, player); // 源 L1973：各附加1层冻结
            }
            if (lib.bts.api.god(player)) lib.bts.api.addAngry(player, 1); // 源 L1975
        },
        ai: {
            // AI 口径：3 怒多目标冻结（禁装备牌+冻结者造成伤害-1，控制敌方输出）；星启施放后回 1 怒
            // （源 L1975）。敌人越多/越接近击杀窗口越积极。（源 animal.lua L1961-1978）
            order(item, player) {
                if (lib.bts.aiGuard.blocked(player, 'bts_sk_bingjian'))
                    return -1;
                let n = 0;
                let low = 0;
                for (const t of game.players) {
                    if (!t.isAlive() || t === player) continue;
                    if (get.attitude(player, t) >= 0) continue;
                    n += 1;
                    if (t.hp <= 2) low += 1;
                }
                if (!n) return -1;
                return 3 + n + (low ? 0.5 : 0); // 每敌≈1 层控制；残血目标冻结临近击杀
            },
            threaten: 2,
            result: {
                player: 1,
                // 目标受损：1 层冻结（禁装备/伤害-1）；残血目标被冻结更接近失去行动窗口
                target: (player, target) => {
                    let v = -1;
                    if (target.hp <= 2) v -= 0.5;
                    return v;
                },
            },
        },
    },

    // ── 特权（源 st_tequan）──
    // 锁定技，当一名角色因受到伤害而移除护盾后，你可以视为对来源使用【杀】。
    // 触发点：rules/globalBuffs.js 护盾抵扣后派发 bts_shield_removed（源：RemoveShield 后
    // findPlayersBySkillName("st_tequan") → ViewAsCardOnly）；效果经技能自注册接通日志/音频。
    bts_sk_tequan: {
        trigger: { global: 'bts_shield_removed' },
        forced: true,
        filter(event) {
            return !!event.source;
        },
        async content(event, trigger, player) {
            const choice = await player
                .chooseBool(
                    `特权：是否视为对${get.translation(trigger.source)}使用【杀】？`,
                )
                // AI 口径：只对存活敌方来源反击（态度<0）；来源即自己/友方时不发动
                .set(
                    'ai',
                    () =>
                        trigger.source !== player &&
                        trigger.source.isAlive() &&
                        get.attitude(player, trigger.source) < 0,
                )
                .forResult();
            if (choice.bool)
                await player.useCard(
                    {
                        name: 'sha',
                        isCard: true,
                        storage: { bts_sk_tequan: true },
                    },
                    trigger.source,
                );
        },
    },

    // ── 可爱（源 st_keai = OneCardViewAsSkill + filter_pattern Slash，L1997-2028）──
    bts_sk_keai: {
        enable: 'phaseUse',
        filterCard(card, player) {
            return get.name(card) === 'sha';
        },
        selectCard: 1,
        position: 'h',
        prompt: '弃置一张【杀】，令一名角色（包括你）附加1层护盾',
        filterTarget(event, player, target) {
            return true;
        }, // 源 filter 仅 #targets==0，可含自己
        selectTarget: 1,
        async content(event, trigger, player) {
            lib.bts.aiGuard.record(player, 'bts_sk_keai');
            const target = event.targets[0];
            if (!target) return;
            await player.discard(event.cards); // 弃置所选【杀】
            lib.bts.api.addShield(target, 1, player); // 源 AddAShield(target, player)
        },
        ai: {
            // AI 口径：弃 1 张【杀】给 1 层护盾；己方（含自己）有残血成员时防斩杀价值更高。
            // （源 animal.lua L1997-2028）
            order(item, player) {
                if (lib.bts.aiGuard.blocked(player, 'bts_sk_keai')) return -1;
                let val = 3;
                if (
                    game.hasPlayer(
                        (t) =>
                            t.isAlive() &&
                            get.attitude(player, t) > 0 &&
                            t.hp <= 2,
                    )
                )
                    val += 1; // 残血友军/自己的护盾防斩杀
                return val;
            },
            useful: 1,
            value: 3,
            result: {
                // 目标获益：1 层护盾≈抵消 1 点伤害；残血目标收益更高
                target: (player, target) => {
                    let v = 1;
                    if (target.hp <= 2) v += 0.5;
                    return v;
                },
            },
        },
    },
};

export const translate = {
    // 可选皮肤显示名（皮肤N；scripts/migrate.mjs --skins 维护，图经 image/skin 目录扫描发现）。
    'bts_ch_sanyueqi_skin1': '皮肤1',
    'bts_ch_sanyueqi_skin10': '皮肤10',
    'bts_ch_sanyueqi_skin11': '皮肤11',
    'bts_ch_sanyueqi_skin12': '皮肤12',
    'bts_ch_sanyueqi_skin13': '皮肤13',
    'bts_ch_sanyueqi_skin14': '皮肤14',
    'bts_ch_sanyueqi_skin15': '皮肤15',
    'bts_ch_sanyueqi_skin16': '皮肤16',
    'bts_ch_sanyueqi_skin17': '皮肤17',
    'bts_ch_sanyueqi_skin18': '皮肤18',
    'bts_ch_sanyueqi_skin19': '皮肤19',
    'bts_ch_sanyueqi_skin2': '皮肤2',
    'bts_ch_sanyueqi_skin20': '皮肤20',
    'bts_ch_sanyueqi_skin21': '皮肤21',
    'bts_ch_sanyueqi_skin22': '皮肤22',
    'bts_ch_sanyueqi_skin3': '皮肤3',
    'bts_ch_sanyueqi_skin4': '皮肤4',
    'bts_ch_sanyueqi_skin5': '皮肤5',
    'bts_ch_sanyueqi_skin6': '皮肤6',
    'bts_ch_sanyueqi_skin7': '皮肤7',
    'bts_ch_sanyueqi_skin8': '皮肤8',
    'bts_ch_sanyueqi_skin9': '皮肤9',
    bts_ch_sanyueqi: '三月七',
    bts_sk_bingjian: '冰箭',
    bts_sk_bingjian_info: `${get.poptip('bts_glossary_bisha_faq')}，出牌阶段，你可以失去3点${get.poptip('bts_glossary_nuqi_faq')}并选择至少一名其他角色，`
        + `这些角色各附加1层${get.poptip('bts_glossary_abnormal_freeze_faq')}，然后若你为${get.poptip('bts_glossary_xingqi_faq')}，`
        + `你回复1点${get.poptip('bts_glossary_nuqi_faq')}。`,
    bts_sk_tequan: '特权',
    bts_sk_tequan_info: `锁定技，当一名角色因受到伤害而移除${get.poptip('bts_glossary_hudun_faq')}后，你可以视为对来源使用【杀】。`,
    bts_sk_keai: '可爱',
    bts_sk_keai_info: `出牌阶段，你可以弃置一张【杀】并选择一名角色，令其附加1层${get.poptip('bts_glossary_hudun_faq')}。`,

    '$bts_sk_bingjian1': "偶尔也该认真一下",
    '$bts_sk_bingjian2': "来尝尝本姑娘的厉害~",
    '$bts_sk_tequan1': "不许跑！",
    '$bts_sk_tequan2': "你再打？",
    '$bts_sk_keai1': "本姑娘出马，怎么可能会输嘛~",
    '$bts_sk_keai2': "乖乖站好，这就给你加个祝福~",
    '~bts_ch_sanyueqi': "我不想…一个人……",
};

export const simpleTranslate = {
    bts_sk_bingjian_info: `${get.poptip('bts_glossary_bisha_faq')}；出牌阶段，-3${get.poptip('bts_glossary_nuqi_faq')}令至少1名其他角色各+1层${get.poptip('bts_glossary_abnormal_freeze_faq')}；`
        + `若${get.poptip('bts_glossary_xingqi_faq')}则+1${get.poptip('bts_glossary_nuqi_faq')}`,
    bts_sk_tequan_info: '锁；一名角色因受到伤害而移除护盾后，可视为对来源使用杀',
    bts_sk_keai_info: `出牌阶段，-1杀令1名角色（含自己）+1层${get.poptip('bts_glossary_hudun_faq')}`,
};

export const pinyins = {}; // 如果默认的拼音正确，不需要再使用字符串数组定义拼音
