// 吉尔伽美什（源 animal.lua L9909-10032）—— 兴致阈值与王之三技。
// 技能：乖离（必杀技·群体虚数通常伤害）、财宝（跳过摸牌+兴致积累，觉醒技）、悦王（他人必杀后增幅）、
//       承认（摸牌阶段把兴致转为摸牌）、允许（他人回合结束获兴致）、背负（手牌【杀】当【过河拆桥】）。
import { lib, game, ui, get, ai, _status, styleText, X, Y, Z, B, O } from '../../shared.js';
import { extensionPath } from '../../../../tool/utils/paths.js';
export const sort = 'yijie';
export const title = '雷·毁灭·古老的英雄王'; // 属性·命途
export const intro =
    `${B('吉尔伽美什')}用${get.poptip('bts_sk_caibao')}跳过摸牌阶段积蓄${get.poptip('bts_glossary_xingzhi_faq')}，达到10枚后觉醒取得${get.poptip('bts_sk_wanglai_chengren')}，摸牌阶段按${get.poptip('bts_glossary_xingzhi_faq')}数多摸牌。`;

export const character = {
    bts_ch_jierjiameishi: {
        sex: 'male',
        group: 'yijie',
        hp: 4,
        skills: ['bts_sk_guaili', 'bts_sk_caibao', 'bts_sk_yuewang'],
    },
};

export const skill = {
    // ── 必杀技·乖离（源 max_guaili = SkillCard + ZeroCardViewAsSkill，L9922-9945）──
    // 出牌阶段，失5怒气，对任意名其他角色各造成1点虚数通常伤害。
    bts_sk_guaili: {
        // 终结技（源必杀技 max_*，描述以「必杀技」开头；bts_bisha 标签供技能按 id 识别终结技）
        bts_bisha: true,
        enable: 'phaseUse',
        // 源描述（L13840）未写「每回合限一次」，仅怒气门槛（GetAngry>=5）——不加 usable:1（按原描述）
        filter(event, player) {
            // 源 enabled_at_play（L9941）：怒气≥5
            return lib.bts.api.getAngry(player, 5);
        },
        filterTarget(card, player, target) {
            // 源 Card filter（L9913）：目标 ≠ 自己
            return target !== player;
        },
        selectTarget: [1, Infinity],
        multitarget: true, // 一次性结算；非 multitarget 会按目标重跑 content（《技能开发规范》B14）
        async content(event, trigger, player) {
            lib.bts.aiGuard.record(player, 'bts_sk_guaili');
            lib.bts.api.loseAngry(player, 5); // 源 L9916：LoseAngry(player, 5)
            for (const target of event.targets) {
                // 源 L9918：reason 含 "_light_common"（虚数属性 + 通常伤害，_common 使 reason 不触发特殊伤害）
                const damage = target.damage(player, 1, 'nocard');
                damage.reason = 'bts_sk_guaili_bts_reason_common_light';
                lib.bts.api.setDamageNature(damage, 'light');
                await damage;
            }
        },
        ai: {
            // AI 口径：5怒气换「敌各1点虚数通常伤害」；无敌人不发动，敌数≥2 时群体收益最高
            //（源 max_guaili，animal.lua L9922-9945）
            order(item, player) {
                if (lib.bts.aiGuard.blocked(player, 'bts_sk_guaili')) return -1;
                const enemies = game.countPlayer(
                    (t) => t.isAlive() && t !== player && get.attitude(player, t) < 0,
                );
                if (!enemies) return -1;
                return enemies >= 2 ? 9 : 8;
            },
            result: {
                // 每目标1点（目标受损；态度加权负责在多人目标间排除友方）
                target: -1,
            },
        },
    },

    // ── 觉醒技·财宝（源 st_caibao = TriggerSkill EventPhaseStart/EventPhaseChanging，L9933-9960）──
    // 锁定技，你跳过摸牌阶段；其他角色回合结束时，其可以令你获得1枚兴致。
    // 觉醒技，你的兴致达到10枚后觉醒：获得承认、允许、背负，然后本技能失效（不再跳过摸牌阶段）。
    bts_sk_caibao: {
        // 源 L9952-9955：EventPhaseChanging to Draw 跳过摸牌；无名杀以准备阶段 player.skip('phaseDraw')
        // 预标（skipList 于摸牌阶段起始检查，等效整段跳）。
        trigger: { global: 'phaseAfter', player: 'phaseZhunbeiBegin' },
        forced: true,
        filter(event, player, triggername) {
            // 源 L9938：他人回合结束才触发（triggername 判变体，event.name 是基名）
            return triggername === 'phaseAfter' ? event.player !== player : true;
        },
        async content(event, trigger, player) {
            if (event.triggername === 'phaseZhunbeiBegin') {
                player.skip('phaseDraw'); // 源 L9955：skip(Player_Draw)
                return;
            }
            // 源 L9941-9944：其他角色回合结束，其可令你获得1枚兴致
            const result = await trigger.player
                .chooseBool(
                    `财宝：是否令${get.translation(player)}获得1枚兴致？`,
                )
                // AI 口径：无代价给予，对吉尔伽美什态度为正即同意（源 st_caibao，L9933-9960）
                .set('ai', () => get.attitude(trigger.player, player) > 0)
                .forResult();
            if (!result.bool) return;
            player.addMark('bts_mk_xingzhi', 1); // 源 L9942：p:gainMark("@xingzhi")
            // 源 L9943：记同意标记（动态键含同意者 playerid）→「允许」据此判定（已修正原漏打）。
            // 固定键镜像承担显示（下一行）；log=false 规避未注册键告警。动态键不能静态注册。
            player.addMark(
                `bts_mk_wanglai_chengren_${trigger.player.playerid}`,
                1,
                false,
            );
            // 累计承认数：挂在承认的计数子技上（计数/统计类只做角标，nopop 不进技能栏/菜单）
            player.addMark('bts_sk_wanglai_chengren_count', 1);
            if (player.countMark('bts_mk_xingzhi') < 10) return; // 源 L9945：未达10枚
            // 源 L9946-9948：达到10枚 → 取得承认/允许/背负。觉醒技用 awakenSkill 失效：财宝留在技能栏
            // （显示为已觉醒），跳过摸牌阶段与赠兴致一并停止，摸牌阶段此后由承认结算。
            await player.addSkill('bts_sk_wanglai_chengren');
            await player.addSkill('bts_sk_wanglai_yunxu');
            await player.addSkill('bts_sk_wanglai_beifu');
            player.awakenSkill('bts_sk_caibao');
        },
    },

    // ── 关联技·承认（源 wanglai_chengren = TriggerSkill Compulsory DrawNCards，L9979-9991）──
    // 锁定技，摸牌阶段额定摸牌数+兴致数，然后弃置全部兴致。
    // 觉醒时由财宝赋予；财宝因觉醒失效后摸牌阶段恢复，此技能才真正生效。
    bts_sk_wanglai_chengren: {
        charlotte: true,
        // 计数子技随本技能一同展开（角标仍由标记生命周期在 addMark 时挂载）
        group: ['bts_sk_wanglai_chengren_count'],
        trigger: { player: 'phaseDrawBegin2' },
        forced: true,
        filter(event, player) {
            return player.countMark('bts_mk_xingzhi') > 0; // 源 L9984：有兴致才触发
        },
        async content(event, trigger, player) {
            // 源 L9986-9988：额定摸牌数 += 兴致，然后清空兴致（改触发事件 phaseDrawBegin2 的 num）
            trigger.num += player.countMark('bts_mk_xingzhi');
            player.removeMark('bts_mk_xingzhi', player.countMark('bts_mk_xingzhi'));
        },
        // 计数子技：累计被同意的次数（纯统计，只承担角标显示）。不写成顶层标记技能：
        // 标记生命周期会 addSkill 到玩家身上；nopop 保证不进技能栏/角色详情，sub+sourceSkill
        // 声明为承认的子技能。图标复用既有 image/mark/bts_mk_wanglai_chengren.png。
        subSkill: {
            count: {
                sub: true,
                sourceSkill: 'bts_sk_wanglai_chengren',
                nopop: true,
                silent: true,
                charlotte: true,
                mark: true,
                marktext: '承',
                intro: {
                    name: '承认',
                    content: (storage) =>
                        `<li>来源：${get.poptip('bts_sk_caibao')}赋予，累计被同意的次数：${storage || 0}</li>`,
                },
                markimage: `${extensionPath}/image/mark/bts_mk_wanglai_chengren.png`,
            },
        },
    },

    // ── 关联技·允许（源 wanglai_yunxu = TriggerSkill Compulsory EventPhaseStart，L9961-9978）──
    // 锁定技，令你获得过兴致的角色回合结束时，你获得2枚兴致（源1枚，当前设计+1）。
    bts_sk_wanglai_yunxu: {
        charlotte: true,
        trigger: { global: 'phaseAfter' },
        forced: true,
        filter(event, player) {
            // 源 L9967-9972：仅「曾同意财宝者」回合结束时才给；以同意标记 bts_mk_wanglai_chengren_<id> 门控。
            return (
                event.player !== player &&
                player.countMark(`bts_mk_wanglai_chengren_${event.player.playerid}`) >
                    0
            );
        },
        async content(event, trigger, player) {
            player.addMark('bts_mk_xingzhi', 2); // 源 L9970：p:gainMark("@xingzhi")；定夺每次+1
        },
    },

    // ── 关联技·背负（源 wanglai_beifu = FilterSkill，L10005-10017）──
    // 锁定技，你的手牌【杀】视为【过河拆桥】：【杀】不能直接使用/响应，只能经本技能当【过河拆桥】用。
    // 源为 FilterSkill 强制全局替换；无名杀以 mod 屏蔽原牌 + viewAs 转化近似（参照 new_jiangchi3 范式）。
    bts_sk_wanglai_beifu: {
        charlotte: true,
        enable: 'chooseToUse',
        filterCard(card) {
            // 源 view_filter（L10008）：手牌且为【杀】
            return get.name(card) === 'sha';
        },
        position: 'h',
        selectCard: 1,
        viewAs: { name: 'guohe', isCard: true }, // 源 L10010-10015：克隆 dismantlement
        mod: {
            // 源 FilterSkill：手牌【杀】不可作为【杀】使用/响应（仅真实手牌，不影响其他技能的虚拟杀）
            cardEnabled(card) {
                if (get.position(card) === 'h' && get.name(card) === 'sha')
                    return false;
            },
            cardRespondable(card) {
                if (get.position(card) === 'h' && get.name(card) === 'sha')
                    return false;
            },
        },
        ai: {
            // ai-guard: skip：viewAs 无独立 content（弃牌转化在使用流程内结算，无内层选择可空转）
            // AI 口径：手牌【杀】已被 mod 禁用使用/响应，当【过河拆桥】打出是唯一用法——有杀即拆牌
            //（源 FilterSkill wanglai_beifu，L10005-10017）
            order(item, player) {
                return player.countCards('h', (c) => get.name(c) === 'sha') > 0
                    ? 6
                    : -1;
            },
            result: {
                // 拆目标1张牌（目标受损）
                target: -1,
            },
        },
    },

    // ── 触发技·悦王（源 st_yuewang = TriggerSkill Compulsory CardFinished，L10012-10031）──
    // 锁定技，其他角色发动必杀技后，你附加1层增幅祝福。
    bts_sk_yuewang: {
        // 源 st_yuewang 是 Compulsory 锁定技（L10027），非必杀技——不标 bts_bisha
        trigger: { global: 'useSkillAfter' },
        forced: true,
        filter(event, player) {
            // 源 L10018-10020：他人使用含 "max_" 的 SkillCard；无名杀改以 bts_bisha 标签判定。
            return (
                event.player !== player &&
                lib.skill[event.skill]?.bts_bisha === true
            );
        },
        async content(event, trigger, player) {
            // 源 L10023：AddBless(p, "@bless_zengfu")
            await lib.bts.api.addBless(player, 'zengfu', 1, player);
        },
    },
};

export const marks = {
    bts_mk_xingzhi: {
        markKind: 'mark',
        glossaryId: 'bts_glossary_xingzhi_faq',
    },
};

export const translate = {
    // 可选皮肤显示名（皮肤N；scripts/migrate.mjs --skins 维护，图经 image/skin 目录扫描发现）。
    'bts_ch_jierjiameishi_skin1': '皮肤1',
    'bts_ch_jierjiameishi_skin2': '皮肤2',
    'bts_ch_jierjiameishi_skin3': '皮肤3',
    bts_ch_jierjiameishi: '吉尔伽美什',
    bts_sk_guaili: '乖离',
    bts_sk_guaili_info: `${get.poptip('bts_glossary_bisha_faq')}，出牌阶段，你可以失去5点${get.poptip('bts_glossary_nuqi_faq')}并选择至少一名其他角色，对这些角色各造成1点${get.poptip('bts_glossary_nature_light_dmg_faq')}通常伤害。`,
    bts_sk_caibao: '财宝',
    bts_sk_caibao_info: `锁定技，你跳过摸牌阶段；其他角色回合结束时，其可以令你获得1枚${get.poptip('bts_glossary_xingzhi_faq')}。觉醒技，当${get.poptip('bts_glossary_xingzhi_faq')}达到10枚后觉醒：你获得${get.poptip('bts_sk_wanglai_chengren')}、${get.poptip('bts_sk_wanglai_yunxu')}和${get.poptip('bts_sk_wanglai_beifu')}，`
        + `然后本技能失效。`,
    bts_sk_yuewang: '悦王',
    bts_sk_yuewang_info: `锁定技，其他角色发动${get.poptip('bts_glossary_bisha_faq')}后，你附加1层${get.poptip('bts_glossary_bless_zengfu_faq')}。`,
    bts_sk_wanglai_chengren: '承认',
    bts_sk_wanglai_chengren_info: `锁定技，摸牌阶段，你弃置全部${get.poptip('bts_glossary_xingzhi_faq')}并多摸等量的牌。`,
    bts_sk_wanglai_yunxu: '允许',
    bts_sk_wanglai_yunxu_info: `锁定技，令你获得过${get.poptip('bts_glossary_xingzhi_faq')}标记的角色的回合结束时，你获得2枚${get.poptip('bts_glossary_xingzhi_faq')}标记。`,
    bts_sk_wanglai_beifu: '背负',
    bts_sk_wanglai_beifu_info: '锁定技，你的【杀】视为【过河拆桥】。',
    bts_mk_xingzhi: '兴致',

    '$bts_sk_guaili1': "醒来吧，Ea!",
    '$bts_sk_guaili2': "知晓原初之理吧——Enuma Elish！",
    '$bts_sk_caibao1': "无聊",
    '$bts_sk_caibao2': "喝彩吧，你们的王回来了！",
    '$bts_sk_yuewang1': "景色真好啊！",
    '$bts_sk_yuewang2': "呵，堪比沙漠中的绿洲啊",
    '$bts_sk_wanglai_beifu1': "轮到你了，天之锁哟！",
    '$bts_sk_wanglai_chengren1': "尽情膜拜吧——呼哈哈哈哈哈哈！",
    '$bts_sk_wanglai_yunxu1': "就陪你玩玩吧",
    '$bts_sk_wanglai_beifu2': "给你上镣铐！",
    '$bts_sk_wanglai_chengren2': "哈哈哈哈哈哈哈哈哈！",
    '$bts_sk_wanglai_yunxu2': "不错，来兴致了",
    '~bts_ch_jierjiameishi': "本王就先抽身了…",
    bts_mk_xingzhi_info: `来源：${get.poptip('bts_sk_caibao')}、${get.poptip('bts_sk_wanglai_yunxu')}赋予；${get.poptip('bts_sk_caibao')}觉醒后，`
        + `${get.poptip('bts_sk_wanglai_chengren')}在摸牌阶段按${get.poptip('bts_glossary_xingzhi_faq')}数多摸牌并清空`,
};

export const simpleTranslate = {
    bts_sk_guaili_info: `${get.poptip('bts_glossary_bisha_faq')}；-5${get.poptip('bts_glossary_nuqi_faq')}对至少1名其他角色各造成1点虚数属性通常伤害`,
    bts_sk_caibao_info: `锁；你跳过摸牌阶段；其他角色的回合结束时，其可令你+1${get.poptip('bts_glossary_xingzhi_faq')}；觉；达到10枚后获得${get.poptip('bts_sk_wanglai_chengren')}${get.poptip('bts_sk_wanglai_yunxu')}${get.poptip('bts_sk_wanglai_beifu')}，`
        + `本技能失效`,
    bts_sk_yuewang_info: `锁；其他角色发动${get.poptip('bts_glossary_bisha_faq')}后，你+1层${get.poptip('bts_glossary_bless_zengfu_faq')}`,
};

// 默认读音有误（什→shí）：按叁岛式写「中文名 → 带声调拼音数组」覆盖。
export const pinyins = {
    '吉尔伽美什': ['jí', 'ěr', 'jiā', 'měi', 'shí'],
};

// ── 角色专属词条（随角色包 gather('glossary') 聚合进 fullTranslate，详见 character/bts/index.js）。
export const glossary = [
    {
        id: 'bts_glossary_xingzhi_faq',
        name: '|兴致|',
        info: `吉尔伽美什专属：${get.poptip('bts_sk_caibao')}、${get.poptip('bts_sk_wanglai_yunxu')}获得；达到10枚由${get.poptip('bts_sk_caibao')}觉醒，此后摸牌阶段由${get.poptip('bts_sk_wanglai_chengren')}按${get.poptip('bts_glossary_xingzhi_faq')}数多摸牌并清空。`,
    },
];
